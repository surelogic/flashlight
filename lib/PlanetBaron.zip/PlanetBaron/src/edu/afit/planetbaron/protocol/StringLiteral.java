package edu.afit.planetbaron.protocol;

/**
 * Represents a name, typically a player name.
 * 
 * @author T.J. Halloran
 * 
 */
public final class StringLiteral extends ASTNode {

  private final String f_value; // not quoted or escaped

  /**
   * Constructs an instance with the given (unquoted) value.
   * 
   * @param value
   *          the string the new instance represents.
   * 
   * @see #removeQuotesAndEscapes(String)
   */
  public StringLiteral(String value) {
    assert value != null && value.length() != 0;
    noNewLineFormFeedOrCarriageReturn(value);
    f_value = value;
  }

  public String getValue() {
    return f_value;
  }

  public String getQuotedAndEscapedName() {
    return addQuotesAndEscapes(f_value);
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    v.visit(this);
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return getQuotedAndEscapedName();
  }

  /**
   * Removes quotes and escapes from the passed string. For example, the string
   * <code>"cat"</code> returns <code>cat</code>. In addition, the escape
   * sequence <code>\"</code> is expanded to <code>"</code>. For example,
   * the string <code>"Mr. \"BIG\""</code> returns <code>Mr. "BIG"</code>.
   * The resulting string must contain at least on character that is not
   * whitespace. For example, <code>" "</code> is not well-formed and will
   * result in {@link IllegalArgumentException} being thrown.
   * 
   * @param s
   *          the quoted string (possibly with <code>\"</code> escapes).
   * @return the unquoted string.
   * @throws IllegalArgumentException
   *           if the string is not surrounded with quotes or if the resulting
   *           string only contains whitespace.
   * @see #addQuotesAndEscapes(String)
   */
  public static String removeQuotesAndEscapes(String s) {
    boolean isWellFormed = (s.length() > 2 && s.startsWith("\"")
        && s.endsWith("\"") && !s.endsWith("\\\""));
    if (!isWellFormed)
      throw new IllegalArgumentException("quoted string not well-formed >" + s
          + "<");
    StringBuilder r = new StringBuilder(s);
    // convert each escape sequence \\ \" \n
    int pos = 0;
    while (true) {
      pos = r.indexOf("\\\"", pos);
      if (pos == -1)
        break;
      r.replace(pos, pos + 2, "\"");
      pos = pos + 1;
    }
    // remove quotes
    r.deleteCharAt(0);
    r.deleteCharAt(r.length() - 1);
    String result = r.toString().trim();
    if (result.length() == 0)
      throw new IllegalArgumentException(
          "quoted string empty or only contains whitespace >" + s + "<");
    return r.toString();
  }

  /**
   * Adds quotes and escapes to the passed string. For example, the string
   * <code>Mr. "BIG"</code> returns <code>"Mr. \"BIG\""</code>.
   * 
   * @param s
   *          the unquoted string (possibly with <code>\"</code> escapes).
   * @return the unquoted string.
   * @see #removeQuotesAndEscapes(String)
   */
  static String addQuotesAndEscapes(String s) {
    StringBuilder r = new StringBuilder(s);
    int pos = 0;
    while (true) {
      pos = r.indexOf("\"", pos);
      if (pos == -1)
        break;
      r.replace(pos, pos + 1, "\\\"");
      pos = pos + 2;
    }
    r.append("\"");
    r.insert(0, "\"");
    return r.toString();
  }

  /**
   * Throws {@link IllegalArgumentException} if the passed string contains a
   * newline, form feed or carriage return.
   * 
   * @param s
   *          the string to check
   * @throws IllegalArgumentException
   *           if the string contains a newline, form feed or carriage return.
   * @see #addQuotesAndEscapes(String)
   * @see #removeQuotesAndEscapes(String)
   */
  private static void noNewLineFormFeedOrCarriageReturn(String s) {
    if (s.indexOf("\n") != -1)
      throw new IllegalArgumentException(
          "string containing \\n is not well-formed >" + s + "<");
    if (s.indexOf("\f") != -1)
      throw new IllegalArgumentException(
          "string containing \\f is not well-formed >" + s + "<");
    if (s.indexOf("\r") != -1)
      throw new IllegalArgumentException(
          "string containing \\r is not well-formed >" + s + "<");
  }
}
