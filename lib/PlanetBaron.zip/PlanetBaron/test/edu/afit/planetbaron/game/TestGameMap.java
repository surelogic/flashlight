package edu.afit.planetbaron.game;

import junit.framework.TestCase;

public class TestGameMap extends TestCase {

  public void testPlayer() {
    GameMap map = GameMap.getInstance();
    assertFalse(map.isPlayer("p1"));
    Player p = map.createPlayer("p1");
    assertTrue(map.isPlayer("p1"));
    assertSame(p, map.getPlayer("p1"));
    try {
      map.getPlayer("p2");
      fail("obtained a reference to a non-existant player");
    } catch (IllegalStateException e) {
      // expected
    }
    try {
      map.createPlayer("p1");
      fail("allowed to create two players with the same name");
    } catch (IllegalStateException e) {
      // expected
    }
  }

  public void testPlanet() {
    GameMap map = GameMap.getInstance();
    assertFalse(map.isPlanet("p1"));
    Planet p = map.createPlanet("p1", Location.getInstance(1, 1));
    assertTrue(map.isPlanet("p1"));
    assertSame(p, map.getPlanet("p1"));
    assertSame(p, map.getPlanetAt(Location.getInstance(1, 1)));
    try {
      map.getPlanet("p2");
      fail("obtained a reference to a non-existant planet");
    } catch (IllegalStateException e) {
      // expected
    }
    try {
      map.createPlanet("p1", Location.getInstance(1, 1));
      fail("allowed to create two planets with the same name");
    } catch (IllegalStateException e) {
      // expected
    }
    try {
      map.createPlanet("p2", Location.getInstance(1, 1));
      fail("allowed to create two planets at the same location");
    } catch (IllegalStateException e) {
      // expected
    }
  }

  public void testShip() {
    GameMap map = GameMap.getInstance();
    Player p1 = map.createPlayer("p1");
    Player p2 = map.createPlayer("p2");

    assertFalse(map.isShip(p1));
    Ship s1 = map.createShip(p1, Location.getInstance(1, 1));
    assertTrue(map.isShip(p1));
    assertSame(s1, map.getShip(map.getPlayer("p1")));
    assertTrue(map.getShipsAt(Location.getInstance(1, 1)).contains(s1));
    assertEquals(1, map.getShipsAt(Location.getInstance(1, 1)).size());
    try {
      map.getShip(p2);
      fail("obtained a reference to a non-existant ship");
    } catch (IllegalStateException e) {
      // expected
    }
    try {
      map.createShip(p1, Location.getInstance(1, 1));
      fail("allowed to create two ships with the same owner");
    } catch (IllegalStateException e) {
      // expected
    }
    Ship s2 = map.createShip(p2, Location.getInstance(1, 1), Location
        .getInstance(5, 5), 1);
    assertTrue(map.getShipsAt(Location.getInstance(1, 1)).contains(s1));
    assertTrue(map.getShipsAt(Location.getInstance(1, 1)).contains(s2));
    assertEquals(2, map.getShipsAt(Location.getInstance(1, 1)).size());
    assertTrue(s2.isMoving());
    assertTrue(s2.getDistanceMoved() > 0.0);
    assertFalse(s1.isMoving());
    s1.moveTo(Location.getInstance(4, 4), 1);
    assertTrue(s1.getDistanceMoved() > 0.0);
  }

  @Override
  protected void tearDown() throws Exception {
    GameMap.getInstance().reset();
  }
}
