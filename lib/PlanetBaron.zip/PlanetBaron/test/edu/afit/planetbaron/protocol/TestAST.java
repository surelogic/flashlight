package edu.afit.planetbaron.protocol;

import edu.afit.planetbaron.game.Location;
import junit.framework.TestCase;

public class TestAST extends TestCase {

  public void testGo() {
    Go c = new Go();
    assertNotNull(c);
    assertEquals("go", ProtocolFacade.parseServerCommand("go").toString());
    // Ouroborus test
    assertEquals(c.toString(), ProtocolFacade.parseServerCommand(c.toString())
        .toString());
  }

  public void testLocationLiteral() {
    LocationLiteral ll_1 = new LocationLiteral(1, 1);
    LocationLiteral ll_2 = new LocationLiteral(Location.getRandomInstance());
    LocationLiteral ll_3 = new LocationLiteral("1", "1");
    assertNotNull(ll_1);
    assertNotNull(ll_2);
    assertNotNull(ll_3);
    assertTrue("references to (1,1) should be the same",
        ll_1.getLocation() == ll_3.getLocation());
    assertSame(ll_1.getLocation(), ProtocolFacade.parseLocation("(1,1)"));
    assertSame(ll_1.getLocation(), ProtocolFacade.parseLocation("(1 , 1    ) "));
    // Ouroborus test
    assertSame(ll_2.getLocation(), ProtocolFacade.parseLocation(ll_2
        .getLocation().toString()));
  }

  public void testLs() {
    Ls c = new Ls();
    assertNotNull(c);
    assertEquals("ls", ProtocolFacade.parseServerCommand("ls").toString());
    // Ouroborus test
    assertEquals(c.toString(), ProtocolFacade.parseServerCommand(c.toString())
        .toString());
  }

  public void testMapSizeReport() {
    MapSizeReport mr = ProtocolFacade.parseMapSizeReport("map size 57x40");
    assertEquals(57, mr.getWidth());
    assertEquals(40, mr.getHeight());
    mr = ProtocolFacade.parseMapSizeReport(mr.toString()); // Ouroborus test
    assertEquals(57, mr.getWidth());
    assertEquals(40, mr.getHeight());
  }

  public void testPlanetReport() {
    PlanetReport pr = ProtocolFacade.parsePlanetReport("planet \"mars\" (3,3)");
    assertEquals("mars", pr.getName());
    assertEquals(Location.getInstance(3, 3), pr.getLocation());
    assertFalse(pr.hasOwner());
    pr = ProtocolFacade.parsePlanetReport(pr.toString()); // Ouroborus test
    assertEquals("mars", pr.getName());
    assertEquals(Location.getInstance(3, 3), pr.getLocation());
    assertFalse(pr.hasOwner());

    pr = ProtocolFacade
        .parsePlanetReport("planet \"mars\" (1,3) owned by \"a\"");
    assertEquals("mars", pr.getName());
    assertEquals(Location.getInstance(1, 3), pr.getLocation());
    assertTrue(pr.hasOwner());
    assertEquals("a", pr.getOwnerName());
    pr = ProtocolFacade.parsePlanetReport(pr.toString()); // Ouroborus test
    assertEquals("mars", pr.getName());
    assertEquals(Location.getInstance(1, 3), pr.getLocation());
    assertTrue(pr.hasOwner());
    assertEquals("a", pr.getOwnerName());
  }

  public void testMoveShip() {
    MoveShip c = new MoveShip(new StringLiteral("player"), new LocationLiteral(
        1, 1));
    assertNotNull(c);
    c = new MoveShip("player", Location.getRandomInstance());
    assertEquals("player", c.getName());
    // Ouroborus test
    assertEquals(c.toString(), ProtocolFacade.parseServerCommand(c.toString())
        .toString());
  }

  public void testProtocolError() {
    ProtocolError e = ProtocolFacade
        .parseProtocolError("ERROR : \"an error\n was sent\" OK");
    assertEquals("an error\n was sent", e.getMessage());
    e = ProtocolFacade.parseProtocolError(e.toString()); // Ouroborus test
    assertEquals("an error\n was sent", e.getMessage());
  }

  public void testShipReport() {
    ShipReport sr = ProtocolFacade.parseShipReport("ship \"player\" (1,1)");
    assertEquals("player", sr.getName());
    assertEquals(Location.getInstance(1, 1), sr.getLocation());
    assertFalse(sr.isMoving());
    assertNull(sr.getDestination());
    sr = ProtocolFacade.parseShipReport(sr.toString()); // Ouroborus test
    assertEquals("player", sr.getName());
    assertEquals(Location.getInstance(1, 1), sr.getLocation());
    assertFalse(sr.isMoving());
    assertNull(sr.getDestination());

    sr = ProtocolFacade.parseShipReport("ship \"p\" (1,1) moving to (5,5)");
    assertEquals("p", sr.getName());
    assertEquals(Location.getInstance(1, 1), sr.getLocation());
    assertTrue(sr.isMoving());
    assertEquals(Location.getInstance(5, 5), sr.getDestination());
    assertEquals(0, sr.getTurnsMoving());
    sr = ProtocolFacade.parseShipReport(sr.toString()); // Ouroborus test
    assertEquals("p", sr.getName());
    assertEquals(Location.getInstance(1, 1), sr.getLocation());
    assertTrue(sr.isMoving());
    assertEquals(Location.getInstance(5, 5), sr.getDestination());
    assertEquals(0, sr.getTurnsMoving());

    sr = ProtocolFacade
        .parseShipReport("ship \"a\" (1,2) moving to (5,6) for 4 turns");
    assertEquals("a", sr.getName());
    assertEquals(Location.getInstance(1, 2), sr.getLocation());
    assertTrue(sr.isMoving());
    assertEquals(Location.getInstance(5, 6), sr.getDestination());
    assertEquals(4, sr.getTurnsMoving());
    sr = ProtocolFacade.parseShipReport(sr.toString()); // Ouroborus test
    assertEquals("a", sr.getName());
    assertEquals(Location.getInstance(1, 2), sr.getLocation());
    assertTrue(sr.isMoving());
    assertEquals(Location.getInstance(5, 6), sr.getDestination());
    assertEquals(4, sr.getTurnsMoving());
  }

  public void testShipVelocityReport() {
    ShipVelocityReport v = ProtocolFacade
        .parseShipVelocityReport("ship-velocity 567");
    assertEquals(567, v.getVelocity_mSQ());
    v = ProtocolFacade.parseShipVelocityReport(v.toString()); // Ouroborus test
    assertEquals(567, v.getVelocity_mSQ());
  }

  public void testStringLiteral() {
    assertNotNull(new StringLiteral("player"));
    assertEquals("player", (new StringLiteral("player")).getValue());
    assertEquals("\"player\"", (new StringLiteral("player")).toString());
    assertEquals("player \"1\"", (ProtocolFacade
        .parseStringLiteral("\"player \\\"1\\\"\"")).getValue());
    assertEquals("\"player \\\"1\\\"\"", (ProtocolFacade
        .parseStringLiteral("\"player \\\"1\\\"\"")).toString());
    try {
      ProtocolFacade.parseStringLiteral(StringLiteral
          .addQuotesAndEscapes("a \n "));
      fail("string with \\n escape should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      ProtocolFacade.parseStringLiteral(StringLiteral
          .addQuotesAndEscapes("a \f "));
      fail("string with \\f escape should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      ProtocolFacade.parseStringLiteral(StringLiteral
          .addQuotesAndEscapes("a \r "));
      fail("string with \\r escape should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  public void testStringLiteralMultiLine() {
    assertEquals("player \"1\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player \\\"1\\\"\"")).getValue());
    assertEquals("\"player \\\"1\\\"\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player \\\"1\\\"\"")).toString());
    assertEquals("player\n \"1\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\n \\\"1\\\"\"")).getValue());
    assertEquals("\"player\n \\\"1\\\"\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\n \\\"1\\\"\"")).toString());
    assertEquals("player\r \"1\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\r \\\"1\\\"\"")).getValue());
    assertEquals("\"player\r \\\"1\\\"\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\r \\\"1\\\"\"")).toString());
    assertEquals("player\f \"1\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\f \\\"1\\\"\"")).getValue());
    assertEquals("\"player\f \\\"1\\\"\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\f \\\"1\\\"\"")).toString());
    assertEquals("player\n\r\f \"1\"\n", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\n\r\f \\\"1\\\"\n\""))
        .getValue());
    assertEquals("\"player\n\r\f \\\"1\\\"\n\"", (ProtocolFacade
        .parseStringLiteralMultiLine("\"player\n\r\f \\\"1\\\"\n\""))
        .toString());
  }

  public void testStringToQuotedString() {
    assertEquals("\"a\"", StringLiteral.addQuotesAndEscapes("a"));
    assertEquals("\"cat\"", StringLiteral.addQuotesAndEscapes("cat"));
    assertEquals("\"cat 1\"", StringLiteral.addQuotesAndEscapes("cat 1"));
    assertEquals("\"cat \\\"do\\\" it\"", StringLiteral
        .addQuotesAndEscapes("cat \"do\" it"));

  }

  public void testPlay() {
    Play c = new Play(new StringLiteral("player"));
    assertNotNull(c);
    assertEquals("play \"player\"", c.toString());
    c = new Play("player");
    assertEquals("player", c.getPlayerName());
    // Ouroborus test
    assertEquals(c.toString(), ProtocolFacade.parseServerCommand(c.toString())
        .toString());
  }

  public void testQuit() {
    Quit c = new Quit();
    assertNotNull(c);
    assertEquals("quit", ProtocolFacade.parseServerCommand("quit").toString());
    // Ouroborus test
    assertEquals(c.toString(), ProtocolFacade.parseServerCommand(c.toString())
        .toString());
  }

  public void testQuotedNameToName() {
    assertEquals("a", StringLiteral.removeQuotesAndEscapes("\"a\""));
    assertEquals("cat", StringLiteral.removeQuotesAndEscapes("\"cat\""));
    assertEquals("cat 1", StringLiteral.removeQuotesAndEscapes("\"cat 1\""));
    assertEquals("cat \"do\" it", StringLiteral
        .removeQuotesAndEscapes("\"cat \\\"do\\\" it\""));

    try {
      StringLiteral.removeQuotesAndEscapes("a");
      fail("string with no quotes should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      StringLiteral.removeQuotesAndEscapes("\"a");
      fail("string with no quotes should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      StringLiteral.removeQuotesAndEscapes("a\"");
      fail("string with no quotes should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      StringLiteral.removeQuotesAndEscapes("\"cat\\\"");
      fail("string ending with \\\" should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      StringLiteral.removeQuotesAndEscapes("\"\"");
      fail("empty string should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
    try {
      StringLiteral.removeQuotesAndEscapes("\"     \"");
      fail("empty string should not be well-formed");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  public void testShutdown() {
    Shutdown c = new Shutdown();
    assertNotNull(c);
    assertEquals("shutdown", ProtocolFacade.parseServerCommand("shutdown")
        .toString());
    // Ouroborus test
    assertEquals(c.toString(), ProtocolFacade.parseServerCommand(c.toString())
        .toString());
  }
}
