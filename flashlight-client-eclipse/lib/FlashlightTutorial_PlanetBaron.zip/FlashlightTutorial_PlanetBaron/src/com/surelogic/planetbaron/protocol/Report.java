package com.surelogic.planetbaron.protocol;

public abstract class Report extends ASTNode {
}
