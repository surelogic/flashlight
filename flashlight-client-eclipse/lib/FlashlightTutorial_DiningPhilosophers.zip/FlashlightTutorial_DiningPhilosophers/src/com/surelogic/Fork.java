package com.surelogic;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * The forks used by five silent philosophers at a round table.
 * <p>
 * Acquiring a fork should be done by obtaining its lock with {@link #getLock()}
 * and then acquiring the lock.
 * <p>
 * The {@link #getGlobalOrder()} method returns an integer that can be used as a
 * global lock order when acquiring locks on two forks at the same
 * time&mdash;lock lower values before higher values to avoid deadlock.
 * 
 * @see Philosopher
 */
public enum Fork {
  ONE, TWO, THREE, FOUR, FIVE;

  private final ReentrantLock lock = new ReentrantLock();

  /**
   * Gets this fork's dynamic lock.
   * 
   * @return this fork's dynamic lock.
   */
  public Lock getLock() {
    return lock;
  }

  /**
   * Checks if the current thread is holding this fork's dynamic lock.
   * 
   * @return {@code true} if the current thread is holding this fork's dynamic
   *         lock, {@code false} otherwise.
   */
  public boolean isHolding() {
    return lock.isHeldByCurrentThread();
  }

  /**
   * Gets an integer that can be used as a global lock order when acquiring
   * locks on two forks at the same time&mdash;lock lower values before higher
   * values to avoid deadlock.
   * 
   * @return this fork's global order value.
   */
  public int getGlobalOrder() {
    return ordinal();
  }
}
