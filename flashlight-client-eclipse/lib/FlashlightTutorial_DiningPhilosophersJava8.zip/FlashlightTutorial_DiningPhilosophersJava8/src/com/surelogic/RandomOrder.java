package com.surelogic;

import java.util.Random;

/**
 * This philosopher strategy randomly chooses the order to pick up the
 * philosopher's two forks.
 * <p>
 * This strategy may deadlock.
 */
public class RandomOrder implements PhilosopherStrategy {

  private final Random coin = new Random();

  @Override
  public Pair<Fork, Fork> chooseForkPickUpOrder(Philosopher philosopher) {
    Fork left = philosopher.getLeft();
    Fork right = philosopher.getRight();

    if (coin.nextBoolean())
      return new Pair<Fork, Fork>(left, right);
    else
      return new Pair<Fork, Fork>(right, left);
  }
}
