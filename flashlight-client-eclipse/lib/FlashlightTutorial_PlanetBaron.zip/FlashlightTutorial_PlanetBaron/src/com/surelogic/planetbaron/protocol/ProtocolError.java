package com.surelogic.planetbaron.protocol;

import com.surelogic.planetbaron.util.Common;

public final class ProtocolError extends ServerResponse {

	private final StringLiteralMultiLine f_message;

	public ProtocolError(StringLiteralMultiLine message) {
		assert message != null;
		f_message = message;
	}

	public ProtocolError(String message) {
		this(new StringLiteralMultiLine(message));
	}

	public String getMessage() {
		return f_message.getValue();
	}

	@Override
	public void accept(ASTVisitor v) {
		v.preVisit(this);
		v.visit(this);
		v.endVisit(this);
		v.postVisit(this);
	}

	@Override
	public String toString() {
		return "ERROR : " + f_message + Common.NL + "OK";
	}
}
