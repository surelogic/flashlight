package edu.afit.planetbaron.server;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import junit.framework.TestCase;

public final class TestTurnCyclicBarrier extends TestCase {

  private static class FauxPlayer extends Thread {

    private int m_turnsLeftToDo;

    private final TurnCyclicBarrier m_myBarrier;

    private final CountDownLatch f_startLatch;

    FauxPlayer(int turnsToDo, TurnCyclicBarrier barrier,
        CountDownLatch startLatch) {
      m_turnsLeftToDo = turnsToDo;
      m_myBarrier = barrier;
      m_myBarrier.incrementPlayerCount();
      f_startLatch = startLatch;
    }

    @Override
    public void run() {
      try {
        f_startLatch.await();
      } catch (InterruptedException e) {
        // ignore
      }
      while (m_turnsLeftToDo-- > 0) {
        m_myBarrier.awaitNextTurn();
      }
      m_myBarrier.decrementPlayerCount();
    }
  }

  private TurnCyclicBarrier m_barrier = null;

  private volatile int m_turnCount = 0;

  final Runnable m_turnListener = new Runnable() {
    public void run() {
      m_turnCount++; // increment the turn count
    }
  };

  public void testSingleThreadedOperations() {
    // do one turn with one player
    m_barrier.incrementPlayerCount();
    m_barrier.awaitNextTurn();
    assertTrue("at turn " + m_turnCount + " should be turn 1", m_turnCount == 1);
    m_barrier.decrementPlayerCount();

    // should still be at turn 1
    assertTrue("at turn " + m_turnCount + " should be turn 1", m_turnCount == 1);

    // do one turn starting with two players
    m_barrier.incrementPlayerCount();
    m_barrier.incrementPlayerCount();
    Thread t = new Thread() {
      @Override
      public void run() {
        m_barrier.awaitNextTurn();
      }
    };
    t.start();
    m_barrier.decrementPlayerCount();
    try {
      t.join();
    } catch (InterruptedException e) {
      fail(e.getMessage());
    }
    assertTrue("at turn " + m_turnCount + " should be turn 2", m_turnCount == 2);

    // do another turn
    m_barrier.awaitNextTurn();
    assertTrue("at turn " + m_turnCount + " should be turn 3", m_turnCount == 3);

    // after removing the last player we should still be at turn 3
    m_barrier.decrementPlayerCount();
    assertTrue("at turn " + m_turnCount + " should be turn 3", m_turnCount == 3);
  }

  public void testMultiThreadedSimpleOperations() {
    // one player doing 500 turns
    CountDownLatch startLatch = new CountDownLatch(1);
    FauxPlayer p = new FauxPlayer(500, m_barrier, startLatch);
    p.start();
    startLatch.countDown();
    try {
      p.join();
    } catch (InterruptedException e) {
      fail(e.getMessage());
    }
    assertTrue("at turn " + m_turnCount + " should be turn 500",
        m_turnCount == 500);

    // two players doing 1000 turns
    startLatch = new CountDownLatch(1);
    FauxPlayer p1 = new FauxPlayer(1000, m_barrier, startLatch);
    FauxPlayer p2 = new FauxPlayer(1000, m_barrier, startLatch);
    p1.start();
    p2.start();
    startLatch.countDown();
    try {
      p1.join();
      p2.join();
    } catch (InterruptedException e) {
      fail(e.getMessage());
    }
    assertTrue("at turn " + m_turnCount + " should be turn 1500",
        m_turnCount == 1500);
  }

  public void testMultiThreadedComplexOperations() {
    CountDownLatch startLatch = new CountDownLatch(1);
    List<FauxPlayer> playerList = new ArrayList<FauxPlayer>(100);
    // create 50 players
    for (int i = 1; i <= 50; i++) {
      // each player plays "i * 100" turns (vary lifespan of a player)
      playerList.add(new FauxPlayer(i * 100, m_barrier, startLatch));
    }
    // start players
    for (FauxPlayer p : playerList) {
      p.start();
    }
    startLatch.countDown();
    // wait for players to exit
    for (FauxPlayer p : playerList) {
      try {
        p.join();
      } catch (InterruptedException e) {
        fail(e.getMessage());
      }
    }
    assertTrue("at turn " + m_turnCount + " should be turn 5000",
        m_turnCount == 5000);
  }

  protected void setUp() throws Exception {
    m_barrier = new TurnCyclicBarrier(m_turnListener);
    m_barrier.setName("TurnCyclicBarrier");
    m_barrier.start();
    m_turnCount = 0;
  }

  protected void tearDown() throws Exception {
    m_barrier.shutdown();
  }
}
