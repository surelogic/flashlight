package edu.afit.planetbaron.protocol;

/**
 * A visitor for abstract syntax trees.
 */
public abstract class ASTVisitor {

  /**
   * Visits the given AST node prior to the type-specific visit. (before visit).
   * The default implementation does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void preVisit(ASTNode node) {
  }

  /**
   * Visits the given AST node following the type-specific visit (after
   * endVisit). The default implementation does nothing. Subclasses may
   * reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void postVisit(ASTNode node) {
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(ConsoleOnly node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(GameStateUpdate node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Go node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(LocationLiteral node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Ls node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Lt node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(MapSizeReport node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(MoveShip node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Ok node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(OkNoResponse node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(PlanetReport node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Play node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(ProtocolError node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Quit node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(ShipReport node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(ShipVelocityReport node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(Shutdown node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(StringLiteral node) {
    return true;
  }

  /**
   * Visits the given type-specific AST node. The default implementation does
   * nothing and return true. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   * @return <code>true</code> if the children of this node should be visited,
   *         and <code>false</code> if the children of this node should be
   *         skipped.
   */
  public boolean visit(StringLiteralMultiLine node) {
    return true;
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(ConsoleOnly node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(GameStateUpdate node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Go node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(LocationLiteral node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Ls node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Lt node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(MapSizeReport node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(MoveShip node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Ok node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(OkNoResponse node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(PlanetReport node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Play node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(ProtocolError node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Quit node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(ShipReport node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(ShipVelocityReport node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(Shutdown node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(StringLiteral node) {
  }

  /**
   * End of visit the given type-specific AST node. The default implementation
   * does nothing. Subclasses may reimplement.
   * 
   * @param node
   *          the node to visit.
   */
  public void endVisit(StringLiteralMultiLine node) {
  }
}
