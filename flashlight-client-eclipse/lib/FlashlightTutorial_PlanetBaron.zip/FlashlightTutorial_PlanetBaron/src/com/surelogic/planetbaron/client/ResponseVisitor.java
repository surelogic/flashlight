package com.surelogic.planetbaron.client;

import com.surelogic.planetbaron.game.GameMap;
import com.surelogic.planetbaron.game.Planet;
import com.surelogic.planetbaron.game.Player;
import com.surelogic.planetbaron.game.Ship;
import com.surelogic.planetbaron.protocol.ASTVisitor;
import com.surelogic.planetbaron.protocol.PlanetReport;
import com.surelogic.planetbaron.protocol.ShipReport;

public final class ResponseVisitor extends ASTVisitor {

	@Override
	public boolean visit(PlanetReport node) {
		GameMap map = GameMap.getInstance();
		Planet p;
		if (map.isPlanet(node.getName())) {
			p = map.getPlanet(node.getName());
		} else {
			p = map.createPlanet(node.getName(), node.getLocation());
		}
		if (node.hasOwner()) {
			Player owner;
			if (map.isPlayer(node.getOwnerName())) {
				owner = map.getPlayer(node.getOwnerName());
			} else {
				owner = map.createPlayer(node.getOwnerName());
			}
			p.setOwner(owner);
		}
		return false;
	}

	@Override
	public boolean visit(ShipReport node) {
		GameMap map = GameMap.getInstance();
		Player owner;
		if (map.isPlayer(node.getName())) {
			owner = map.getPlayer(node.getName());
		} else {
			owner = map.createPlayer(node.getName());
		}
		if (map.isShip(owner)) {
			Ship s = map.getShip(owner);
			if (node.isMoving()) {
				/*
				 * We need to ignore this update (likely to ourselves) if the
				 * ship is already moving.
				 */
				if (!s.isMoving()) {
					s.moveTo(node.getDestination(), node.getTurnsMoving());
				}
			}
		} else {
			map.createShip(owner, node.getLocation(), node.getDestination(),
					node.getTurnsMoving());
		}
		return false;
	}
}
