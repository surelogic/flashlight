package com.surelogic.java6;

/**
 * This philosopher strategy always picks up the fork to the left, and then the
 * fork to the right.
 * <p>
 * This strategy may deadlock.
 */
public class LeftThenRight extends PhilosopherStrategy {

  @Override
  public Pair<Fork, Fork> chooseForkPickUpOrder(Philosopher philosopher) {
    return new Pair<Fork, Fork>(philosopher.getLeft(), philosopher.getRight());
  }
}
