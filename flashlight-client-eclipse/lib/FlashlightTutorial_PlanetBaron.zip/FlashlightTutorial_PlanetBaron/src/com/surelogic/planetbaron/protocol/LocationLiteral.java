package com.surelogic.planetbaron.protocol;

import com.surelogic.planetbaron.game.Location;

public final class LocationLiteral extends ASTNode {

	private final Location f_location;

	public LocationLiteral(Location l) {
		assert l != null;
		f_location = l;
	}

	public LocationLiteral(int x, int y) {
		this(Location.getInstance(x, y));
	}

	public LocationLiteral(String x, String y) {
		this(Integer.parseInt(x), Integer.parseInt(y));
	}

	public Location getLocation() {
		return f_location;
	}

	@Override
	public void accept(ASTVisitor v) {
		v.preVisit(this);
		v.visit(this);
		v.endVisit(this);
		v.postVisit(this);
	}

	@Override
	public String toString() {
		return f_location.toString();
	}
}
