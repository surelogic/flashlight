package com.surelogic.planetbaron.protocol;

public final class Go extends ServerCommand {

	@Override
	public void accept(ASTVisitor v) {
		v.preVisit(this);
		v.visit(this);
		v.endVisit(this);
		v.postVisit(this);
	}

	@Override
	public String toString() {
		return "go";
	}
}
