package com.surelogic.android;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public final class CounterThread extends Thread {

  /**
   * A race condition should occur on this unsafe shared counter.
   */
  private static long f_sharedCounter = 0L;

  static void incSharedCounter() {
    f_sharedCounter++;
  }

  public static void clearSharedCounter() {
    f_sharedCounter = 0L;
  }

  public static long getSharedCounter() {
    return f_sharedCounter;
  }

  public CounterThread(CountDownLatch startLatch) {
    f_startLatch = startLatch;
  }

  private final CountDownLatch f_startLatch;
  private final AtomicBoolean f_running = new AtomicBoolean(true);
  private long f_threadLocalCounts = 0L;

  @Override
  public void run() {
    try {
      f_startLatch.await();
    } catch (InterruptedException ignore) {
      ignore.printStackTrace();
    }
    while (f_running.get()) {
      incSharedCounter();
      f_threadLocalCounts++; // safe, thread confined
    }
  }

  public void stopSafely() {
    f_running.set(false);
  }

  public long getThreadLocalCounterIncrements() {
    return f_threadLocalCounts;
  }
}
