//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by jedinstl.rc
//
#define IDS_REG_CTX_SERVER_KEY          1
#define IDS_REG_UNINSTALL_KEY           2
#define IDS_REG_DEFERMOVE_KEY           3
#define IDS_REG_LAUNCHER_PARAM_KEY      4
#define IDS_REG_CTXMENU_KEY             5
#define IDS_JEDIT_DESC                  6
#define IDS_QUERY_REINSTALL             7
#define IDS_REG_JAVAPARAM_DEFAULT       8
#define IDS_QUERY_UNINSTALL             9
#define IDS_SHORTCUT_JEDINIT            10
#define IDS_SHORTCUT_JEDIT              11
#define IDS_SHORTCUT_UNINSTALL          12
#define IDS_QUERY_REBOOT				13
#define IDS_MSG_INCOMPLETE				14
#define IDS_QUERY_UNINSTALL_FULL        15
#define IDS_QUERY_UNREGISTER            16
#define IDD_CHOOSE_CTX_DIALOG           101
#define IDI_JEDIT_UNINSTALL             102
#define IDC_LIST_VERSIONS               1000
#define IDS_JEL_VERSION_01              1024
#define IDS_JEL_VERSION_02              1025
#define IDS_JEL_VERSION_03              1026
#define IDS_JEL_VERSION_04              1027
#define IDS_JEL_VERSION_05              1028
#define IDS_JEL_VERSION_06              1029
#define IDS_JEL_VERSION_07              1030
#define IDS_JEL_VERSION_08              1031
#define IDS_JEL_VERSION_09              1032
#define IDS_JEL_VERSION_10              1033
#define IDS_JEL_VERSION_11              1034
#define IDS_JEL_VERSION_12              1035
#define IDS_JEL_VERSION_13              1036
#define IDS_JEL_VERSION_14              1037
#define IDS_JEL_VERSION_15              1038
#define IDS_JEL_VERSION_16              1039
#define IDS_JEL_VERSION_17              1040
#define IDS_JEL_VERSION_18              1041
#define IDS_JEL_VERSION_19              1042
#define IDS_JEL_VERSION_20              1043
#define IDS_JEL_VERSION_21              1044
#define IDS_JEL_VERSION_22              1045
#define IDS_JEL_VERSION_23              1046
#define IDS_JEL_VERSION_24              1047
#define IDS_JEL_VERSION_25              1048
#define IDS_JEL_VERSION_26              1049
#define IDS_JEL_VERSION_27              1050
#define IDS_JEL_VERSION_28              1051
#define IDS_JEL_VERSION_29              1052
#define IDS_JEL_VERSION_30              1053
#define IDS_JEL_VERSION_31              1054
#define IDS_JEL_VERSION_32              1055
#define IDS_JEL_VERSIONNAME_01          1088
#define IDS_JEL_VERSIONNAME_02          1090
#define IDS_JEL_VERSIONNAME_03          1091
#define IDS_JEL_VERSIONNAME_04          1092
#define IDS_JEL_VERSIONNAME_05          1093
#define IDS_JEL_VERSIONNAME_06          1094
#define IDS_JEL_VERSIONNAME_07          1095
#define IDS_JEL_VERSIONNAME_08          1096


// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
