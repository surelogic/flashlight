package com.surelogic;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Based on the classic Dining Philosophers problem. Five philosophers sit down
 * at a table with five plates, five forks, and a bowl of spaghetti in the
 * middle. A philosopher is either thinking or eating, and they must have two
 * forks to eat from the bowl of spaghetti. The philosophers never speak to each
 * other.
 *
 * In this example, each philosopher is represented by a separate thread, and
 * the forks are util.concurrent locks. A philosopher must acquire a lock on
 * both nearby locks in order to eat.
 */
public class DiningPhilosophers {

	public static void main(String[] args) {
		DiningPhilosophers d = new DiningPhilosophers();
		d.startEating(DiningPhilosophers::leftThenRightPhilosopher);
		try {
			Thread.sleep(30000);
		} catch (final InterruptedException e) {
			// Do nothing
		}
		System.exit(0);
	}

	enum Philosopher {
		Kant, Diogenes, Descartes, Goethe, Russell;
		private static final Lock[] forks;

		static {
			forks = new Lock[values().length];
			for (Philosopher p : values()) {
				forks[p.ordinal()] = new ReentrantLock();
			}
		}

		void tryLeftFork(ThrowsInterrupted success, ThrowsInterrupted failure)
				throws InterruptedException {
			Lock lock = forks[ordinal()];
			boolean locked = lock.tryLock();
			if (locked) {
				try {
					success.run();
				} finally {
					lock.unlock();
				}
			} else {
				failure.run();
			}
		}

		void tryRightFork(ThrowsInterrupted success, ThrowsInterrupted failure)
				throws InterruptedException {
			Lock lock = forks[(ordinal() + 1) % values().length];
			boolean locked = lock.tryLock();
			if (locked) {
				try {
					success.run();
				} finally {
					lock.unlock();
				}
			} else {
				failure.run();
			}
		}

		Fork acquireLeftFork() {
			return new Fork(forks[ordinal()]);
		}

		Fork acquireRightFork() {
			return new Fork(forks[(ordinal() + 1) % values().length]);
		}

	}

	/**
	 * An {@link AutoCloseable} wrapper around a lock, this represents a fork
	 * held by a philosopher.
	 *
	 * @author nathan
	 *
	 */
	static class Fork implements AutoCloseable {
		private final Lock lock;

		Fork(Lock lock) {
			this.lock = lock;
			lock.lock();
		}

		@Override
		public void close() {
			lock.unlock();
		}

	}

	/**
	 * A functional interface that takes a {@link Philosopher}. The
	 * implementation of eat should attempt to acquire both locks.
	 *
	 * @author nathan
	 *
	 */
	interface PhilosopherStrategy {
		void eat(Philosopher philosopher) throws InterruptedException;

		default Thread startThread(Philosopher phil) {
			Thread thread = new Thread(() -> {
				for (;;) {
					try {
						eat(phil);
					} catch (InterruptedException e) {
						// Do nothing
				}
				}
			}	);
			thread.start();
			return thread;
		}
	}

	interface ThrowsInterrupted {
		void run() throws InterruptedException;
	}

	/**
	 * Start a thread for each philosopher that attempts to execute the given
	 * strategy
	 *
	 * @param strategy
	 */
	void startEating(PhilosopherStrategy strategy) {
		Philosopher[] philosophers = Philosopher.values();
		for (Philosopher phil : philosophers) {
			strategy.startThread(phil);
		}
	}

	/**
	 * This philosopher always attempts to take the fork on their left, and then
	 * the fork on their right.
	 *
	 *
	 */
	static void leftThenRightPhilosopher(Philosopher phil)
			throws InterruptedException {
		System.out.printf("%s is thinking.\n", phil);
		Thread.sleep(1000);
		try (Fork left = phil.acquireLeftFork()) {
			System.out.printf("%s picks up the left fork.\n", phil);
			Thread.sleep(1000);
			try (Fork right = phil.acquireRightFork()) {
				System.out.printf("%s picks up the right fork.\n", phil);
				Thread.sleep(1000);
				System.out.printf("%s is eating.\n", phil);
				Thread.sleep(1000);
			}
		}
	}

	private static final Random r = new Random();

	/**
	 * This philosopher randomly chooses a fork to grab first.
	 *
	 */
	static void randomPhilosopher(Philosopher phil) throws InterruptedException {
		boolean leftFirst = r.nextBoolean();
		System.out.printf("%s is thinking.\n", phil);
		Thread.sleep(1000);
		try (Fork first = leftFirst ? phil.acquireLeftFork() : phil
				.acquireRightFork()) {
			System.out.printf("%s picks up the %s fork.\n", phil,
					leftFirst ? "left" : "right");
			Thread.sleep(1000);
			try (Fork second = leftFirst ? phil.acquireRightFork() : phil
					.acquireLeftFork()) {
				System.out.printf("%s picks up the %s fork.\n", phil,
						leftFirst ? "right" : "left");
				Thread.sleep(1000);
				System.out.printf("%s is eating.\n", phil);
				Thread.sleep(1000);
			}
		}
	}

	/**
	 * A common strategy to prevent deadlock is to assign every lock an ordinal
	 * value, then always acquire locks from lowest to highest. In our example
	 * we assume each fork is assigned an ordinal value, such that the first
	 * philosopher's left and right forks would be 0 and 1 respectively, the
	 * second philosopher 1 and 2. This continues up until the final
	 * philosopher, who around a table with n philosophers would have forks
	 * (n-1) and 0.
	 *
	 * This allows us to use a consistent locking order by always locking the
	 * lowest numbered fork. For every philosopher but the final one this is
	 * just the left fork. For the final philosopher, however, it is the right
	 * fork.
	 *
	 */
	static void orderedPhilosopher(Philosopher phil)
			throws InterruptedException {
		boolean leftFirst = phil.ordinal() != Philosopher.values().length - 1;
		System.out.printf("%s is thinking.\n", phil);
		Thread.sleep(1000);
		try (Fork first = leftFirst ? phil.acquireLeftFork() : phil
				.acquireRightFork()) {
			System.out.printf("%s picks up the %s fork.\n", phil,
					leftFirst ? "left" : "right");
			Thread.sleep(1000);
			try (Fork second = leftFirst ? phil.acquireRightFork() : phil
					.acquireLeftFork()) {
				System.out.printf("%s picks up the %s fork.\n", phil,
						leftFirst ? "right" : "left");
				Thread.sleep(1000);
				System.out.printf("%s is eating.\n", phil);
				Thread.sleep(1000);
			}
		}
	}

	/**
	 * This philosopher always locks from left to right, but will relinquish its
	 * first lock if it can't immediately get the second.
	 *
	 */
	static void politePhilosopher(Philosopher phil) throws InterruptedException {
		System.out.printf("%s is thinking.\n", phil);
		Thread.sleep(1000);
		phil.tryLeftFork(() -> {
			System.out.printf("%s picks up the left fork.\n", phil);
			Thread.sleep(1000);
			phil.tryRightFork(() -> {
				System.out.printf("%s picks up the right fork.\n", phil);
				Thread.sleep(1000);
				System.out.printf("%s is eating.\n", phil);
				Thread.sleep(1000);
			}, () -> {
				System.out.printf(
						"%s puts down his fork and politely waits his turn.\n",
						phil);
			});
		}, () -> {
			System.out.printf("%s thinks a moment longer.\n", phil);
			Thread.sleep(1000);
		});
	}

}
