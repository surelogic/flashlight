package com.surelogic;

/**
 * This philosopher strategy always picks up the fork to the right, and then the
 * fork to the left.
 * <p>
 * This strategy may deadlock.
 */
public class RightThenLeft implements PhilosopherStrategy {

  @Override
  public Pair<Fork, Fork> chooseForkPickUpOrder(Philosopher philosopher) {
    return new Pair<Fork, Fork>(philosopher.getRight(), philosopher.getLeft());
  }
}
