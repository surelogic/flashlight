package edu.afit.planetbaron.protocol;

public abstract class ASTNode {

  private ASTNode f_parent = null;

  /**
   * Returns the parent node of this node, or <code>null</code> if this node
   * has no parent node.
   * 
   * @return the parent node of this node, or <code>null</code> if this node
   *         has no parent node.
   */
  public final ASTNode getParent() {
    return f_parent;
  }

  /**
   * Sets the parent node of this node. Only intended to be called by
   * constructors within subclasses.
   * 
   * @param parent
   *          the non-null parent node of this node.
   */
  final void setParent(ASTNode parent) {
    assert parent != null;
    f_parent = parent;
  }

  /**
   * Accepts the given visitor on a visit of the current node.
   * 
   * @param v
   *          the visitor object
   */
  public abstract void accept(final ASTVisitor v);
}
