package com.surelogic.planetbaron.protocol;

public abstract class ServerResponse extends ASTNode {
}
