                              Flashlight Ant Tasks
--------------------------------------------------------------------------------

Flashlight-related ANT tasks are declared in the JAR file
flashlight-ant.jar. The best way to load the Flashlight ANT tasks into ANT and
into their own namespace is to use the ANT <taskdef> tag:

<?xml version="1.0" encoding="ISO-8859-1"?>
<project ... xmlns:flashlight="antlib:com.surelogic.flashlight.ant">
    <taskdef uri="antlib:com.surelogic.flashlight.ant"
    		resource="com/surelogic/flashlight/ant/antlib.xml"
    		classpath="path/to/flashlight-ant.jar"/>
    ...

  

The flashlight tasks can now be referred to using the the task names
<flashlight:taskname>.  For more information on how to use these tasks, see the
help documentation provided with the Flashlight Eclipse Client.
