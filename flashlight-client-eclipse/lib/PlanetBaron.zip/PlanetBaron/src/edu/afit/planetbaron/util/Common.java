package edu.afit.planetbaron.util;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * An ad hoc collection of useful static stuff for the game. This is the
 * proverbial kitchen sink.
 * 
 * @author T.J. Halloran
 */
public final class Common {

	private static final Logger LOG = ConciseFormatter.getLogger("common");

	/**
	 * A newline string used by the game protocol.
	 */
	public static final String NL = "\n\r";

	/**
	 * Default port the game server listens on. This can be changed by setting
	 * its associated property, <code>planetbaron.defaultPort</code>.
	 */
	public static final int DEFAULT_PORT = Integer.parseInt(System.getProperty(
			"planetbaron.defaultPort", "8693"));

	/**
	 * Random number generator for the game. This can be changed, for example to
	 * 450, by setting <code>-Dplanetbaron.randomSeed=450</code> as a JVM
	 * argument.
	 */
	public static final Random rand = new Random(Long.parseLong(System
			.getProperty("planetbaron.randomSeed", "327671")));

	/**
	 * The logical width, like a chess board, of the map. This can be changed by
	 * setting its associated property, <code>planetbaron.logicalMapWidth</code>.
	 */
	public static int LOGICAL_MAP_WIDTH = Integer.parseInt(System.getProperty(
			"planetbaron.logicalMapWidth", "15"));

	/**
	 * The logical height, like a chess board, of the map. This can be changed
	 * by setting its associated property,
	 * <code>planetbaron.logicalMapHeight</code>.
	 */
	public static int LOGICAL_MAP_HEIGHT = Integer.parseInt(System.getProperty(
			"planetbaron.logicalMapHeight", "15"));

	/**
	 * The number of planets the server randomly places on the map. This can be
	 * changed by setting its associated property,
	 * <code>planetbaron.planetCount</code>.
	 */
	public static final int PLANET_COUNT = Integer.parseInt(System.getProperty(
			"planetbaron.planetCount", "30"));

	public static final int SHIP_VELOCITY_mSQ = 100;

	/**
	 * Represents the velocity a ship can travel in map coordinates per turn.
	 * This can be changed by setting its associated property,
	 * <code>planetbaron.shipVelocity</code>.
	 */
	public static double SHIP_VELOCITY = SHIP_VELOCITY_mSQ / 1000.0;

	public static final String[] PLANET_NAMES = { "Abechpevu", "Azovnomo",
			"Ifekbifu", "Opimbishu", "Usifteto", "Acinkaku", "Ebespothi",
			"Ifichchaxi", "Oripvomo", "Usubsuxa", "Acuncoca", "Ecuchsuki",
			"Ikamfoge", "Orokvona", "Utexvali", "Adevcheso", "Edithsodo",
			"Ikeshpini", "Osinvache", "Uthutpomu", "Aforfaro", "Efedtoxi",
			"Ilexmixo", "Ovektido", "Utufpulo", "Agalthora", "Efixthuro",
			"Inagshuko", "Oxomzecho", "Uvachkave", "Agishtidu", "Eginvaco",
			"Irizvosha", "Uchalxixe", "Ycugzore", "Agoszeza", "Ekaxcagi",
			"Isechthara", "Udimbibu", "Yfaktote", "Akitcogo", "Ekeshtogu",
			"Isochshesa", "Udumzixa", "Ykarteco", "Akuvzivo", "Ekigpisha",
			"Izufkacho", "Ugoxgaxe", "Ykopzosho", "Alapthozi", "Ekodfuxa",
			"Obikcida", "Ukilpono", "Ylimnufa", "Aligcovu", "Elultava",
			"Obikzoti", "Ukoshbazi", "Yloshfeza", "Anothnilu", "Emeffonu",
			"Ochakgagi", "Ulappaci", "Yludtoku", "Apifsofu", "Eniptoto",
			"Ochipvoti", "Umaxlape", "Yninthovi", "Ashevxexi", "Ereshbala",
			"Ochogshanu", "Unibvapa", "Ypuffodi", "Asiprimi", "Erucnire",
			"Okegxosi", "Uniczela", "Yredgishe", "Asuchthiru", "Esemvute",
			"Okinshoma", "Unozthipi", "Yrefzumo", "Avidchobe", "Eshurfobo",
			"Oloplefi", "Uratcore", "Ysimfocha", "Avikfopa", "Ichuchveshe",
			"Onefgacha", "Uroplasi", "Ytochletha", "Azonbucha", "Idichlashe",
			"Opapthedo", "Usacliza", "Yvuthchasho" };

	/**
	 * Welcome message sent from the server to all clients. This is used to
	 * identify to the client that the server talks the game protocol it
	 * expects.
	 */
	public static final String serverWelcomeMessage = "Welcome to PlanetBaron protocol 1.0";

	/**
	 * Pulls out the first instance of a quoted string. For example, consider
	 * the string <code>s</code> containing:
	 * <p>
	 * <code>"a good [example] of [time]"</code>
	 * <p>
	 * The call <code>findQuotedText(s,"[","]")</code> would return the string:
	 * <code>"example"</code>
	 * 
	 * @param buffer
	 *            string to search for quoted string within
	 * @param beginQPattern
	 *            pattern that start quotes the item of interest
	 * @param endQPattern
	 *            pattern that end quotes the item of interest
	 * @param after
	 *            if not <code>null</code> this will be mutated to add the rest
	 *            of the string after the returned quoted pattern (for the
	 *            example above, after.append(" of [time]")), if the quoted
	 *            pattern is not found this is not mutated
	 * @return The string extracted from the buffer or <code>null</code> if
	 *         something caused the extraction to fail
	 */
	public static String findQuotedText(String buffer, String beginQPattern,
			String endQPattern, StringBuilder after) {
		int beginQStartIndex = buffer.indexOf(beginQPattern);
		if (beginQStartIndex == -1)
			return null;
		int beginQEndIndex = beginQStartIndex + beginQPattern.length();
		int endQStartIndex = buffer.indexOf(endQPattern, beginQEndIndex);
		if (endQStartIndex == -1)
			return null;
		int afterIndex = endQStartIndex + 1;
		if (afterIndex < buffer.length()) {
			if (after != null)
				after.append(buffer.substring(afterIndex));
		}
		return buffer.substring(beginQEndIndex, endQStartIndex);
	}

	/**
	 * Reads in the complete contents of a text file.
	 * 
	 * @param file
	 *            the file to read
	 * @return the file contents
	 */
	public static String readStringFromFile(java.io.File file) {
		String fileContents = new String();
		try {
			java.io.BufferedReader in = new java.io.BufferedReader(
					new java.io.FileReader(file));
			String s;
			while ((s = in.readLine()) != null) {
				fileContents += s + "\n";
			}
			in.close();
		} catch (java.io.IOException e) {
			LOG.log(Level.SEVERE, "failed to read in contents of the file \""
					+ file.getAbsolutePath() + "\"", e);
		}
		return fileContents;
	}

	/**
	 * Writes out a string to a text file.
	 * 
	 * @param file
	 *            the file to create
	 * @param buffer
	 *            the string to output
	 */
	public static void writeStringToFile(java.io.File file, String buffer) {
		try {
			java.io.PrintWriter out = new java.io.PrintWriter(
					new java.io.BufferedWriter(new java.io.FileWriter(file)));
			out.print(buffer);
			out.close();
		} catch (java.io.IOException e) {
			LOG.log(Level.SEVERE, "failed to write out file \""
					+ file.getAbsolutePath() + "\"", e);
		}
	}
}
