package edu.afit.planetbaron.protocol;

public final class Play extends ServerCommand {

  private final StringLiteral f_playerName;

  public Play(StringLiteral playerName) {
    assert playerName != null;
    f_playerName = playerName;
    f_playerName.setParent(this);
  }

  public Play(String playerName) {
    this(new StringLiteral(playerName));
  }

  public String getPlayerName() {
    return f_playerName.getValue();
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    if (v.visit(this)) {
      f_playerName.accept(v);
    }
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return "play " + f_playerName;
  }
}
