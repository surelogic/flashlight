package edu.afit.planetbaron.protocol;

public final class OkNoResponse extends ServerResponse {

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    v.visit(this);
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return "OK";
  }
}
