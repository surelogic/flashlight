package edu.afit.planetbaron.protocol;

public final class ConsoleOnly extends ServerResponse {

  private final String f_text;

  /**
   * @param text
   *          the text sent to the client.
   */
  public ConsoleOnly(String text) {
    assert (text != null);
    f_text = text.trim();
  }

  @Override
  public void accept(ASTVisitor v) {
    v.preVisit(this);
    v.visit(this);
    v.endVisit(this);
    v.postVisit(this);
  }

  @Override
  public String toString() {
    return f_text;
  }
}
