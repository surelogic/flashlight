package com.surelogic.planetbaron.protocol;

public abstract class ServerCommand extends ASTNode {
}
