package com.surelogic;

import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Based on the classic Dining Philosophers problem. Five philosophers sit down
 * at a table with five plates, five forks, and a bowl of spaghetti in the
 * middle. A philosopher is either thinking or eating, and they must have two
 * forks to eat from the bowl of spaghetti. The philosophers never speak to each
 * other.
 * 
 * In this example, each philosopher is represented by a separate thread, and
 * the forks are util.concurrent locks. A philosopher must acquire a lock on
 * both nearby locks in order to eat.
 */
public class DiningPhilosophers {

	private static final String[] names = new String[] { "Kant", "Diogenes",
			"Descartes", "Goethe", "Russell" };

	public static void main(String[] args) {
		Fork[] forks = new Fork[5];
		for (int i = 0; i < 5; i++) {
			forks[i] = new Fork(i);
		}
		for (int i = 0; i < 5; i++) {
			new Thread(new RandomPhilosopher(names[i], forks[i],
					forks[(i + 1) % 5])).start();
		}
	}

	private static final Random r = new Random();

	/**
	 * Each fork happens to be numbered, and this philosopher will always grab
	 * the lowest numbered fork next to them.
	 * 
	 */
	static class OrderedPhilosopher implements Runnable {
		private final String name;
		private final Fork left;
		private final Fork right;

		OrderedPhilosopher(String name, Fork left, Fork right) {
			this.name = name;
			this.left = left;
			this.right = right;
		}

		public void run() {
			while (true) {
				try {
					boolean leftFirst = left.ordinal() < right.ordinal();
					System.out.printf("%s is thinking.\n", name);
					Thread.sleep(1000);
					Fork first = leftFirst ? left : right;
					first.lock();
					try {
						System.out.printf("%s picks up the %s fork.\n", name,
								leftFirst ? "left" : "right");
						Thread.sleep(1000);
						Fork second = leftFirst ? right : left;
						second.lock();
						try {
							System.out.printf("%s picks up the %s fork.\n",
									name, leftFirst ? "right" : "left");
							Thread.sleep(1000);
							System.out.printf("%s is eating.\n", name);
							Thread.sleep(1000);
						} finally {
							second.unlock();
						}
					} finally {
						first.unlock();
					}
				} catch (InterruptedException e) {
					// Do nothing
				}
			}
		}
	}

	/**
	 * This philosopher randomly chooses a fork to grab first, but will
	 * relinquish it and wait if they cannot acquire a second fork.
	 * 
	 */
	static class PolitePhilosopher implements Runnable {
		private final String name;
		private final Fork left;
		private final Fork right;

		PolitePhilosopher(String name, Fork left, Fork right) {
			this.name = name;
			this.left = left;
			this.right = right;
		}

		public void run() {
			while (true) {
				try {
					boolean leftFirst = r.nextBoolean();
					System.out.printf("%s is thinking.\n", name);
					Thread.sleep(1000);
					Fork first = leftFirst ? left : right;
					while (!first.tryLock()) {
						System.out.printf("%s thinks a moment longer.\n", name);
						Thread.sleep(1000);
					}
					try {
						System.out.printf("%s picks up the %s fork.\n", name,
								leftFirst ? "left" : "right");
						Thread.sleep(1000);
						Fork second = leftFirst ? right : left;
						if (second.tryLock()) {
							try {
								System.out.printf("%s picks up the %s fork.\n",
										name, leftFirst ? "right" : "left");
								Thread.sleep(1000);
								System.out.printf("%s is eating.\n", name);
								Thread.sleep(1000);
							} finally {
								second.unlock();
							}
						} else {
							System.out
									.printf(
											"%s puts down his fork and politely waits his turn.\n",
											name);
						}
					} finally {
						first.unlock();
					}
				} catch (InterruptedException e) {
					// Do nothing
				}
			}
		}
	}

	/**
	 * This philosopher randomly chooses a fork to grab first.
	 * 
	 */
	static class RandomPhilosopher implements Runnable {
		private final String name;
		private final Fork left;
		private final Fork right;

		RandomPhilosopher(String name, Fork left, Fork right) {
			this.name = name;
			this.left = left;
			this.right = right;
		}

		public void run() {
			while (true) {
				try {
					boolean leftFirst = r.nextBoolean();
					System.out.printf("%s is thinking.\n", name);
					Thread.sleep(1000);
					Fork first = leftFirst ? left : right;
					first.lock();
					try {
						System.out.printf("%s picks up the %s fork.\n", name,
								leftFirst ? "left" : "right");
						Thread.sleep(1000);
						Fork second = leftFirst ? right : left;
						second.lock();
						try {
							System.out.printf("%s picks up the %s fork.\n",
									name, leftFirst ? "right" : "left");
							Thread.sleep(1000);
							System.out.printf("%s is eating.\n", name);
							Thread.sleep(1000);
						} finally {
							right.unlock();
						}
					} finally {
						left.unlock();
					}
				} catch (InterruptedException e) {
					// Do nothing
				}
			}
		}
	}

	/**
	 * This philosopher always attempts to take the fork on their left, and then
	 * the fork on their right.
	 * 
	 * 
	 */
	static class LeftThenRightPhilosopher implements Runnable {
		private final String name;
		private final Fork left;
		private final Fork right;

		LeftThenRightPhilosopher(String name, Fork left, Fork right) {
			this.name = name;
			this.left = left;
			this.right = right;
		}

		public void run() {
			while (true) {
				try {
					System.out.printf("%s is thinking.\n", name);
					Thread.sleep(1000);
					left.lock();
					try {
						System.out.printf("%s picks up the left fork.\n", name);
						Thread.sleep(1000);
						right.lock();
						try {
							System.out.printf("%s picks up the right fork.\n",
									name);
							Thread.sleep(1000);
							System.out.printf("%s is eating.\n", name);
							Thread.sleep(1000);
						} finally {
							right.unlock();
						}
					} finally {
						left.unlock();
					}
				} catch (InterruptedException e) {
					// Do nothing
				}
			}
		}
	}

	/**
	 * The table forks are represented by locks. A philosopher must lock on the
	 * Fork object in order to acquire the fork.
	 * 
	 * 
	 */
	@SuppressWarnings("serial")
	static class Fork extends ReentrantLock {
		private final int ord;

		Fork(int ord) {
			this.ord = ord;
		}

		int ordinal() {
			return ord;
		}
	}

}
