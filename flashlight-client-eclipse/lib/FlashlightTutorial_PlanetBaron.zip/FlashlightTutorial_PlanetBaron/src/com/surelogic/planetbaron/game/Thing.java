package com.surelogic.planetbaron.game;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;

import com.surelogic.planetbaron.util.ConciseFormatter;

/**
 * Abstract base class for all things which exist on a {@link GameMap}. This
 * class is intended to be extended.
 * <p>
 * This class maintains the reverse link back to the containing game map,
 * accessed via a call to {@link #getMap()}. The class also defines a read-write
 * lock, {@link #f_lock}, for protecting the mutable state of subclasses.
 */
public abstract class Thing {

	/**
	 * A logger for subclasses.
	 */
	protected static final Logger LOG = ConciseFormatter.getLogger("things");

	private final GameMap f_map; // immutable

	Thing(GameMap map) {
		assert map != null;
		f_map = map;
	}

	public GameMap getMap() {
		return f_map;
	}

	/**
	 * Protects the state of this object including state added by subclasses.
	 */
	protected final ReadWriteLock f_lock = new ReentrantReadWriteLock();
}
