package com.surelogic.java6;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * Implemented to provide a strategy for an individual philosopher to eat. Some
 * approaches may deadlock others may not.
 * <p>
 * The key method that must be implemented is
 * <p>
 * Invoke {@link #dine()} to start the meal.
 * 
 * @see Philosopher
 * @see Fork
 */
public abstract class PhilosopherStrategy {

  public static final int TIMES_TO_EAT_WHEN_DINING = 10;

  /**
   * Returns the order the passed philosopher's forks should be picked up.
   * <p>
   * This method should only be invoked from {@link #dine()}.
   * 
   * @param philosopher
   *          a philosopher.
   * @return a pair, the first value is the fork that should be picked up first,
   *         the second value is the fork that should be picked up second.
   */
  abstract public Pair<Fork, Fork> chooseForkPickUpOrder(Philosopher philosopher);

  /**
   * Starts the meal. Each philosopher will try to eat
   * {@link #TIMES_TO_EAT_WHEN_DINING} times and then stop. The meal is
   * concurrent in the sense that each philosopher will act within its own
   * thread.
   * <p>
   * A {@link CountDownLatch} is used to ensure all the philosopher threads
   * begin dining together.
   * <p>
   * This call blocks and waits for the meal to be completed.
   */
  public final void dine() {
    System.out.println("--------- Dining Philosophers ---------");
    final CountDownLatch latch = new CountDownLatch(1);
    final List<Thread> philosopherThreads = new ArrayList<Thread>();
    for (final Philosopher philosopher : Philosopher.values()) {
      Thread philosopherThread = new Thread(new Runnable() {
        public void run() {
          try {
            latch.await();
            for (int i = 1; i <= TIMES_TO_EAT_WHEN_DINING; i++) {
              pickUpBothForksAndEat(philosopher, chooseForkPickUpOrder(philosopher), i);
            }
            philosopher.finishedDining();
          } catch (InterruptedException ignore) {
          }
        }
      });
      philosopherThread.setName(philosopher.toString());
      philosopherThreads.add(philosopherThread);
      philosopherThread.start();
    }
    latch.countDown();
    for (Thread philosopherThread : philosopherThreads) {
      while (philosopherThread.isAlive())
        try {
          philosopherThread.join();
        } catch (InterruptedException ignore) {
        }
    }
    System.out.println("--------- Dining Complete ---------");
  }

  /**
   * Implements the details of a philosopher eating after acquiring the lock on
   * his forks in the passed order.
   * <p>
   * This method should only be invoked from {@link #dine()}.
   * 
   * @param philosopher
   *          a philosopher.
   * @param order
   *          a pair, the first value is the fork that should be picked up
   *          first, the second value is the fork that should be picked up
   *          second.
   * @param count
   *          the count of how many times the philosopher has eaten (for
   *          logging).
   */
  public final void pickUpBothForksAndEat(Philosopher philosopher, Pair<Fork, Fork> order, int count) {
    Fork fork1 = order.first();
    Fork fork2 = order.second();

    philosopher.thinking();

    fork1.getLock().lock();
    try {
      philosopher.picksUp(fork1);

      fork2.getLock().lock();
      try {
        philosopher.picksUp(fork2);

        philosopher.eating(count);
      } finally {
        fork2.getLock().unlock();
      }
      philosopher.putsDown(fork2);
    } finally {
      fork1.getLock().unlock();
    }
    philosopher.putsDown(fork1);
  }
}