package com.surelogic.android;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

public class CounterRaceActivity extends Activity {

  private static final int THREAD_COUNT = 4;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
    setContentView(R.layout.main);

    f_control = (CheckBox) findViewById(R.id.check_box);
    f_results = (TextView) findViewById(R.id.results);

    f_control.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
      @Override
      public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked)
          go();
        else
          stop();
      }
    });
  }

  @Override
  protected void onPause() {
    super.onPause();

    if (f_running) {
      f_running = false;

      for (CounterThread thread : f_threads) {
        thread.stopSafely();
      }
      f_threads.clear();
    }
  }

  @Override
  protected void onResume() {
    super.onResume();

    setProgressBarIndeterminateVisibility(false);
    if (f_control != null) {
      f_control.setChecked(false);
      f_control.setText(getResources().getString(R.string.counter_go));
    }
  }

  /*
   * Thread confined to the Android UI thread
   */
  private CheckBox f_control;
  private TextView f_results;
  private boolean f_running;
  private List<CounterThread> f_threads = new ArrayList<CounterThread>();

  void go() {
    if (!f_running) {
      f_running = true;
      setProgressBarIndeterminateVisibility(true);
      f_control.setText(getResources().getString(R.string.counter_stop));

      CountDownLatch start = new CountDownLatch(1);
      CounterThread.clearSharedCounter();

      for (int i = 0; i < THREAD_COUNT; i++)
        f_threads.add(new CounterThread(start));

      for (Thread thread : f_threads) {
        thread.start();
      }
      start.countDown(); // off to the races!
    }
  }

  void stop() {
    if (f_running) {
      f_running = false;
      setProgressBarIndeterminateVisibility(false);
      f_control.setText(getResources().getString(R.string.counter_go));

      for (CounterThread thread : f_threads) {
        thread.stopSafely();
      }
      Thread.yield();

      /*
       * Here we need to be sure all the threads have stopped before we get the
       * number of attempted increments each thread did on the shared counter.
       */
      for (Thread thread : f_threads) {
        try {
          thread.join();
        } catch (InterruptedException ignore) {
          ignore.printStackTrace();
        }
      }

      /*
       * Now we can get the count date from the threads and the shared counter.
       */
      long attemptedIncs = 0L;
      for (CounterThread thread : f_threads) {
        attemptedIncs += thread.getThreadLocalCounterIncrements();
      }
      f_threads.clear();
      long observedIncs = CounterThread.getSharedCounter();

      final StringBuilder b = new StringBuilder();
      int procCount = Runtime.getRuntime().availableProcessors();
      b.append(procCount);
      b.append(" processor");
      if (procCount > 1)
        b.append("s");
      b.append(" available");
      b.append("\n\nAttempted Incs=");
      b.append(attemptedIncs);
      b.append("\nObserved Incs=");
      b.append(observedIncs);
      if (attemptedIncs == observedIncs) {
        b.append("\n\nThe shared counter worked properly");
      } else {
        final long missed = attemptedIncs - observedIncs;
        final int perMissed = (int) (((double) missed / (double) attemptedIncs) * 100.0);
        b.append("\n\nA data race on the shared counter was observed\n\n");
        b.append(perMissed);
        b.append("% of attempted increments were lost due to the data race");
      }

      f_results.setText(b.toString());
    }
  }
}
