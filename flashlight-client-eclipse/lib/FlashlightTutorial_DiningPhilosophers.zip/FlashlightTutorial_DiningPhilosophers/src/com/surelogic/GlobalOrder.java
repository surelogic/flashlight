package com.surelogic;

/**
 * This philosopher strategy uses the global order stored in its forks to pickup
 * forks in a consistent order across all philosophers at the table.
 * <p>
 * This strategy will not deadlock.
 */
public class GlobalOrder extends PhilosopherStrategy {

  @Override
  public Pair<Fork, Fork> chooseForkPickUpOrder(Philosopher philosopher) {
    Fork left = philosopher.getLeft();
    Fork right = philosopher.getRight();

    if (left.getGlobalOrder() < right.getGlobalOrder())
      return new Pair<Fork, Fork>(left, right);
    else
      return new Pair<Fork, Fork>(right, left);
  }
}
