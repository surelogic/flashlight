Some basic python scripts which use the REST interface:

zk_dump_tree.py -- dumps the nodes & data of a znode hierarchy

Generally these scripts require:
  * simplejson
