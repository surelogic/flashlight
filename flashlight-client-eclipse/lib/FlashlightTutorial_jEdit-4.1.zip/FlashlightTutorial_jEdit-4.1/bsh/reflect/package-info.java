/**
 * @-module Bsh for *
 */
package bsh.reflect;
