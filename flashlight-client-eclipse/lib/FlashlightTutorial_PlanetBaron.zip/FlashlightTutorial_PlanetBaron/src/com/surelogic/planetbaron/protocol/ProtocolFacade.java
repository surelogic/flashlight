package com.surelogic.planetbaron.protocol;

import java.io.Reader;
import java.io.StringReader;

import com.surelogic.planetbaron.game.Location;
import com.surelogic.planetbaron.protocol.parser.ParseException;
import com.surelogic.planetbaron.protocol.parser.ProtocolParser;

public final class ProtocolFacade {

	/**
	 * Parses the string argument as a server command.
	 * 
	 * @param s
	 *            a string containing the server command to parse
	 * @return an AST representing the server command.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static ServerCommand parseServerCommand(String s) {
		return parse(s, new ParseStrategy<ServerCommand>() {
			public ServerCommand parse(ProtocolParser parser)
					throws ParseException {
				return parser.ServerCommand();
			}
		});
	}

	/**
	 * Parses the string argument as a server response.
	 * 
	 * @param s
	 *            a string containing the server response.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static ServerResponse parseServerResponse(String s) {
		return parse(s, new ParseStrategy<ServerResponse>() {
			public ServerResponse parse(ProtocolParser parser)
					throws ParseException {
				return parser.ServerResponse();
			}
		});
	}

	/**
	 * Parses the string argument as a location. For example, the string "(2,3)"
	 * would return a location with coordinates x=2 and y=3.
	 * 
	 * @param s
	 *            a string containing the location value to parse.
	 * @return the location.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed or the new location is not on the
	 *             game map.
	 */
	public static Location parseLocation(String s) {
		return parse(s, new ParseStrategy<Location>() {
			public Location parse(ProtocolParser parser) throws ParseException {
				return parser.LocationLiteral().getLocation();
			}
		});
	}

	/**
	 * Parses the string argument as a single line string literal. This method
	 * is primarily for testing.
	 * 
	 * @param s
	 *            a string containing the quoted and escaped string to parse.
	 * @return an AST representing the string literal.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static StringLiteral parseStringLiteral(String s) {
		return parse(s, new ParseStrategy<StringLiteral>() {
			public StringLiteral parse(ProtocolParser parser)
					throws ParseException {
				return parser.StringLiteral();
			}
		});
	}

	/**
	 * Parses the string argument as a (possibly) multi-line string literal.
	 * This method is primarily for testing.
	 * 
	 * @param s
	 *            a string containing the quoted and escaped string to parse.
	 * @return an AST representing the string literal.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static StringLiteralMultiLine parseStringLiteralMultiLine(String s) {
		return parse(s, new ParseStrategy<StringLiteralMultiLine>() {
			public StringLiteralMultiLine parse(ProtocolParser parser)
					throws ParseException {
				return parser.StringLiteralMultiLine();
			}
		});
	}

	/**
	 * Parses the string argument as a planet report. This method is primarily
	 * for testing.
	 * 
	 * @param s
	 *            a string containing the planet report.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static PlanetReport parsePlanetReport(String s) {
		return parse(s, new ParseStrategy<PlanetReport>() {
			public PlanetReport parse(ProtocolParser parser)
					throws ParseException {
				return parser.PlanetReport();
			}
		});
	}

	/**
	 * Parses the string argument as a ship report. This method is primarily for
	 * testing.
	 * 
	 * @param s
	 *            a string containing the ship report.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static ShipReport parseShipReport(String s) {
		return parse(s, new ParseStrategy<ShipReport>() {
			public ShipReport parse(ProtocolParser parser)
					throws ParseException {
				return parser.ShipReport();
			}
		});
	}

	/**
	 * Parses the string argument as a map size report. This method is primarily
	 * for testing.
	 * 
	 * @param s
	 *            a string containing the map size report.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static MapSizeReport parseMapSizeReport(String s) {
		return parse(s, new ParseStrategy<MapSizeReport>() {
			public MapSizeReport parse(ProtocolParser parser)
					throws ParseException {
				return parser.MapSizeReport();
			}
		});
	}

	/**
	 * Parses the string argument as a ship velocity report. This method is
	 * primarily for testing.
	 * 
	 * @param s
	 *            a string containing the ship velocity report.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static ShipVelocityReport parseShipVelocityReport(String s) {
		return parse(s, new ParseStrategy<ShipVelocityReport>() {
			public ShipVelocityReport parse(ProtocolParser parser)
					throws ParseException {
				return parser.ShipVelocityReport();
			}
		});
	}

	/**
	 * Parses the string argument as a game state update. This method is
	 * primarily for testing.
	 * 
	 * @param s
	 *            a string containing the game state update.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static GameStateUpdate parseGameStateUpdate(String s) {
		return parse(s, new ParseStrategy<GameStateUpdate>() {
			public GameStateUpdate parse(ProtocolParser parser)
					throws ParseException {
				return parser.GameStateUpdate();
			}
		});
	}

	/**
	 * Parses the string argument as a protocol error. This method is primarily
	 * for testing.
	 * 
	 * @param s
	 *            a string containing the protocol error.
	 * @return an AST representing the string.
	 * @throws IllegalArgumentException
	 *             if the string is ill-formed, i.e., it doesn't parse.
	 */
	public static ProtocolError parseProtocolError(String s) {
		return parse(s, new ParseStrategy<ProtocolError>() {
			public ProtocolError parse(ProtocolParser parser)
					throws ParseException {
				return parser.ProtocolError();
			}
		});
	}

	/**
	 * The context of the protocol parsing strategy pattern.
	 * 
	 * @param <T>
	 *            the resulting type from the parse this strategy invokes.
	 * @param s
	 *            the string to parse.
	 * @param strategy
	 *            the strategy to use for the parse.
	 * @return the AST resulting from the parse.
	 */
	public static <T> T parse(String s, ParseStrategy<T> strategy) {
		Reader stream = new StringReader(s);
		ProtocolParser parser = new ProtocolParser(stream);
		try {
			return strategy.parse(parser);
		} catch (Throwable e) {
			throw new IllegalArgumentException(e);
		}
	}

	private ProtocolFacade() {
		// no instances
	}
}
