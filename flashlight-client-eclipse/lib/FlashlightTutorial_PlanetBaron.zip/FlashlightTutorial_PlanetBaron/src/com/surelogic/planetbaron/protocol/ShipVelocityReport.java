package com.surelogic.planetbaron.protocol;

public final class ShipVelocityReport extends Report {

	private final int f_velocity_mSQ;

	public ShipVelocityReport(int velocity_mSQ) {
		f_velocity_mSQ = velocity_mSQ;
	}

	public int getVelocity_mSQ() {
		return f_velocity_mSQ;
	}

	@Override
	public void accept(ASTVisitor v) {
		v.preVisit(this);
		v.visit(this);
		v.endVisit(this);
		v.postVisit(this);
	}

	@Override
	public String toString() {
		return "ship-velocity " + f_velocity_mSQ;
	}
}
