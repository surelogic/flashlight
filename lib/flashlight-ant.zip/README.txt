                              Flashlight Ant Tasks
--------------------------------------------------------------------------------

Flashlight-related ANT tasks are declared in the JAR file
flashlight-ant.jar. This file depends on the files flashlight-rewriter.jar and
asm-3.1.jar. All three files must be in the same directory, although only
flashlight-ant.jar needs to be declared to ant.
