package com.surelogic.planetbaron.protocol;

public abstract class ConsoleOnlyCommand extends ServerCommand {
}
