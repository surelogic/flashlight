package com.surelogic;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;

import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;

/**
 * A Java implementation of the classic <a
 * href="http://en.wikipedia.org/wiki/Dining_philosophers_problem">Dining
 * Philosophers</a> problem. Five philosophers sit down at a table with five
 * plates, five forks, and a bowl of spaghetti in the middle. A philosopher is
 * either thinking or eating, and they must have two forks to eat from the bowl
 * of spaghetti. The philosophers never speak to each other.
 * <p>
 * In this implementation, each philosopher is represented by a separate thread,
 * and the forks are util.concurrent locks. A philosopher must acquire a lock on
 * both nearby locks in order to eat. Several philosopher implementations are
 * provided&mdash;some may deadlock.
 */
public class DiningPhilosophers {

  private static final String[] names = new String[] { "Kant", "Diogenes", "Descartes", "Goethe", "Russell" };

  public static void main(String[] args) {
    Fork[] forks = new Fork[5];
    for (int i = 0; i < 5; i++) {
      forks[i] = new Fork(i);
    }
    for (int i = 0; i < 5; i++) {
      String name = names[i];
      int left = i;
      int right = (i + 1) % 5;
      new Thread(new LeftThenRightPhilosopher(name, forks[left], forks[right]), name).start();
    }
    // run for 10 seconds and then exit the program
    try {
      Thread.sleep(MILLISECONDS.convert(10, SECONDS));
    } catch (final InterruptedException ignore) {
    }
    System.exit(0);
  }

  /**
   * The table forks are represented by locks. A philosopher must lock on the
   * Fork object in order to acquire the fork.
   * <p>
   * A lock acquisition order is stored within the fork but is only used by the
   * {@link OrderedPhilosopher} implementation.
   */
  @SuppressWarnings("serial")
  static class Fork extends ReentrantLock {
    private final int lockAcqisitionOrder;

    Fork(int lockAcquisitionOrder) {
      this.lockAcqisitionOrder = lockAcquisitionOrder;
    }

    /**
     * Gets the lock acquisition order. Lower values should be acquired first.
     * <p>
     * This value is only used by the {@link OrderedPhilosopher} implementation.
     * 
     * @return the lock acquisition order
     */
    int getLockAcquisitionOrder() {
      return lockAcqisitionOrder;
    }
  }

  /**
   * One second duration in milliseconds.
   */
  static final long ONE_SECOND = MILLISECONDS.convert(1, SECONDS);

  /**
   * This philosopher always attempts to take the fork on their left, and then
   * the fork on their right.
   * <p>
   * This philosopher implementation may deadlock.
   */
  static class LeftThenRightPhilosopher implements Runnable {
    private final String name;
    private final Fork left;
    private final Fork right;

    LeftThenRightPhilosopher(String name, Fork left, Fork right) {
      this.name = name;
      this.left = left;
      this.right = right;
    }

    @Override
    public void run() {
      while (true) {
        try {
          System.out.printf("%s is thinking.\n", name);
          Thread.sleep(ONE_SECOND);
          left.lock();
          try {
            System.out.printf("%s picks up the left fork.\n", name);
            Thread.sleep(ONE_SECOND);
            right.lock();
            try {
              System.out.printf("%s picks up the right fork.\n", name);
              Thread.sleep(ONE_SECOND);
              System.out.printf("%s is eating.\n", name);
              Thread.sleep(ONE_SECOND);
            } finally {
              right.unlock();
            }
          } finally {
            left.unlock();
          }
        } catch (InterruptedException ignore) {
        }
      }
    }
  }

  /**
   * This philosopher uses the lock acquisition order stored in its forks to
   * grab the forks in a consistent "global" fork order.
   * <p>
   * This philosopher implementation will not deadlock.
   */
  static class OrderedPhilosopher implements Runnable {
    private final String name;
    private final Fork left;
    private final Fork right;

    OrderedPhilosopher(String name, Fork left, Fork right) {
      this.name = name;
      this.left = left;
      this.right = right;
    }

    @Override
    public void run() {
      while (true) {
        try {
          boolean leftFirst = left.getLockAcquisitionOrder() < right.getLockAcquisitionOrder();
          System.out.printf("%s is thinking.\n", name);
          Thread.sleep(ONE_SECOND);
          Fork first = leftFirst ? left : right;
          first.lock();
          try {
            System.out.printf("%s picks up the %s fork.\n", name, leftFirst ? "left" : "right");
            Thread.sleep(ONE_SECOND);
            Fork second = leftFirst ? right : left;
            second.lock();
            try {
              System.out.printf("%s picks up the %s fork.\n", name, leftFirst ? "right" : "left");
              Thread.sleep(ONE_SECOND);
              System.out.printf("%s is eating.\n", name);
              Thread.sleep(ONE_SECOND);
            } finally {
              second.unlock();
            }
          } finally {
            first.unlock();
          }
        } catch (InterruptedException ignore) {
        }
      }
    }
  }

  /*
   * The implementation below is not used in the tutorial but can be used to
   * test out Flashlight on other schemes.
   */

  /**
   * This philosopher randomly chooses a fork to grab first by flipping a coin
   * then grabs the second.
   * <p>
   * This philosopher implementation may deadlock, but probably not as quickly
   * the {@link LeftThenRightPhilosopher} implementation.
   */
  static class RandomPhilosopher implements Runnable {
    private final String name;
    private final Fork left;
    private final Fork right;
    private final Random coin = new Random();

    RandomPhilosopher(String name, Fork left, Fork right) {
      this.name = name;
      this.left = left;
      this.right = right;
    }

    @Override
    public void run() {
      while (true) {
        try {
          boolean leftFirst = coin.nextBoolean();
          System.out.printf("%s is thinking.\n", name);
          Thread.sleep(ONE_SECOND);
          final Fork first = leftFirst ? left : right;
          first.lock();
          try {
            System.out.printf("%s picks up the %s fork.\n", name, leftFirst ? "left" : "right");
            Thread.sleep(ONE_SECOND);
            final Fork second = leftFirst ? right : left;
            second.lock();
            try {
              System.out.printf("%s picks up the %s fork.\n", name, leftFirst ? "right" : "left");
              Thread.sleep(ONE_SECOND);
              System.out.printf("%s is eating.\n", name);
              Thread.sleep(ONE_SECOND);
            } finally {
              second.unlock();
            }
          } finally {
            first.unlock();
          }
        } catch (InterruptedException ignore) {
        }
      }
    }
  }
}
