package com.surelogic.java6;

/**
 * Five silent philosophers at a round table. Each philosopher knows which fork
 * is to his right and which fork is to his left.
 *
 * @see Fork
 */
public enum Philosopher {
  Kant(Fork.ONE, Fork.TWO),
  Diogenes(Fork.TWO, Fork.THREE),
  Descartes(Fork.THREE, Fork.FOUR),
  Goethe(Fork.FOUR, Fork.FIVE),
  Russell(Fork.FIVE, Fork.ONE);

  private Philosopher(Fork left, Fork right) {
    this.left = left;
    this.right = right;
  }

  private final Fork left, right;

  /**
   * Gets the fork to the left of this philosopher.
   * 
   * @return the fork to the left of this philosopher.
   */
  public Fork getLeft() {
    return left;
  }

  /**
   * Gets the fork to the right of this philosopher.
   * 
   * @return the fork to the right of this philosopher.
   */
  public Fork getRight() {
    return right;
  }

  /*
   * The below methods nicely log events to the console and double check the
   * program's state.
   */

  /**
   * When the philosopher wants to think.
   */
  public void thinking() {
    log("is thinking");
  }

  /**
   * When the philosopher picks up the passed fork.
   * <p>
   * The philosopher thread must be holding the lock on the passed fork.
   * 
   * @param fork
   *          the fork the philosopher picks up.
   * @throws IllegalStateException
   *           if not holding the lock on the passed fork.
   */
  public void picksUp(Fork fork) {
    if (fork == left && fork.isHolding())
      log("picks up the left fork");
    else if (fork == right && fork.isHolding())
      log("picks up the right fork");
    else
      throw new IllegalStateException(this + " is not holding the lock on fork " + fork);
  }

  /**
   * When the philosopher puts down the passed fork.
   * <p>
   * The philosopher thread must not be holding the lock on the passed fork.
   * 
   * @param fork
   *          the fork the philosopher puts down.
   * @throws IllegalStateException
   *           if holding the lock on the passed fork.
   */
  public void putsDown(Fork fork) {
    if (fork == left && !fork.isHolding())
      log("puts down the left fork");
    else if (fork == right && !fork.isHolding())
      log("puts down the right fork");
    else
      throw new IllegalStateException(this + " is holding the lock on fork " + fork);
  }

  /**
   * When the philosopher wants to eat. He must be holding the lock on both the
   * fork to his left and the fork to his right.
   * 
   * @param count
   *          the count of how many times the philosopher has eaten.
   * 
   * @throws IllegalStateException
   *           if not holding the lock on both the fork to his left and the fork
   *           to his right.
   */
  public void eating(int count) {
    if (left.isHolding() && right.isHolding()) {
      log("is eating (has now eaten " + count + (count == 1 ? " time)" : " times)"));
    } else
      throw new IllegalStateException(this + " told to eat without holding two forks");
  }

  /**
   * When the philosopher is finished dining.
   */
  public void finishedDining() {
    log("is finished dining");
  }

  private void log(String value) {
    String name = String.format("%0$9s %s", this.toString(), value);
    System.out.println(name);
  }
}
