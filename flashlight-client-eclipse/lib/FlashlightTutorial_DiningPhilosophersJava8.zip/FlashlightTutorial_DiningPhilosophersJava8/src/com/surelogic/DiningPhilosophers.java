package com.surelogic;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Main program for the Java 8 <a
 * href="http://en.wikipedia.org/wiki/Dining_philosophers_problem">Dining
 * Philosophers</a> implementation.
 */
public class DiningPhilosophers {
  public static void main(String[] args) {
    boolean done = false;
    int strategyChoice = 0;
    do {
      System.out.println("What strategy should the philosophers use to choose the order to pick up their forks?");
      System.out.println("1. Left fork followed by right fork (may deadlock)");
      System.out.println("2. Right fork followed by left fork  (may deadlock)");
      System.out.println("3. Randomly choose order each time (may deadlock)");
      System.out.println("4. Order all the forks on the table and have all philosophers pick them up in that order");
      System.out.print("Enter number your choice: ");
      Pair<Boolean, Integer> result = tryToReadIntegerFromConsole();
      if (result.first()) {
        int choice = result.second();
        if (choice > 0 && choice <= 4) {
          done = true;
          strategyChoice = choice;
        }
      } else {
        System.out.println("Invalid entry, please try again...");
      }
    } while (!done);

    final PhilosopherStrategy strategy;
    boolean mayDeadlock = true;
    switch (strategyChoice) {
    case 1:
      strategy = new LeftThenRight();
      break;
    case 2:
      strategy = new RightThenLeft();
      break;
    case 3:
      strategy = new RandomOrder();
      break;
    case 4:
      strategy = new GlobalOrder();
      mayDeadlock = false;
      break;
    default:
      throw new IllegalStateException();
    }
    System.out.println();
    System.out.println("Note: Each philosopher will eat " + PhilosopherStrategy.TIMES_TO_EAT_WHEN_DINING
        + " times during this meal");
    System.out.println("Note: Using strategy " + strategy.getClass().getSimpleName());
    if (mayDeadlock)
      System.out.println("Note: If the output hangs before the program completes then deadlock has occurred (please terminate)");
    strategy.dine();
  }

  /**
   * Tries to read an integer from the console.
   * 
   * @return ({@code true}, the integer) if successful, ({@code false},
   *         {@code null}) otherwise.
   */
  static Pair<Boolean, Integer> tryToReadIntegerFromConsole() {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    try {
      String rawInput = br.readLine();
      int value = Integer.parseInt(rawInput);
      return new Pair<Boolean, Integer>(true, value);
    } catch (Exception ioe) {
      return new Pair<Boolean, Integer>(false, null);
    }
  }
}
