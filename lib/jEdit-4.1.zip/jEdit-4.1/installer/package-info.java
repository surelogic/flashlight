/**
 * @-module Installer for *
 */
package installer;
