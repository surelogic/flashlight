package edu.afit.planetbaron.game;

/**
 * Defines the protocol for a mutable game object (like ships and planets). Each
 * game turn, {@link #doTurn()} is invoked.
 * 
 * @author T.J. Halloran
 */
public interface TurnMutable {

	/**
	 * Invoked once per turn to allow this object to change any state which is
	 * mutating over time (for example, moving a ship).
	 */
	void doTurn();
}
